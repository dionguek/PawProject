function isPNG(file){
    if (file.type != "img/png" && file.type != "image/png"){        
        return false;
    }
    return true;
}

function isJPEG(file){
    if (file.type != "img/jpeg" && file.type != "image/jpeg"){        
        return false;
    }
    return true;
}

function reloadPNG(img_id){
    d = new Date();
    var img_url = $(img_id).attr("src");
    img_url = img_url + "?" + d.getTime();
    $(img_id).attr("src", img_url);
}

function customizebtn_onClick(form) {
    $('#progress-' + form.id).width("0%")
    $('#select-' + form.id).click();
}

function reset_onClick() {
    $.ajax({
        url:"reset-customization" ,
        type:"POST",
        data:"",
        contentType:false,
        processData:false,
        cache:false,
        
        success:function(resp){ 
            reloadPNG("#img-bg1920");
            reloadPNG("#img-bg1024");
            reloadPNG("#img-logo");
        },
        error:function(resp){
            if(resp.status == "403"){
                window.location.replace("/admin/login");
                return;
            }
            $("#error-text").text("Failed to reset customization. Please try again");
            $('#modal-error').openModal();
        },        
    });
    return false;
}

function uploadPNG(event){    
    var label = $(this).val().replace(/\\/g, '/').replace(/.*\//, '');  
    var files = $(this).get(0).files;
    var formData = new FormData($(this)[0]); 
    formData.append("file", files[0], files[0].name);
    
    if ( isPNG(files[0]) == false &&
         isJPEG(files[0]) == false ){
        $("#error-text").text("Image must be a PNG or JPEG file");
        $('#modal-error').openModal();
        return false;
    }
    
    $.ajax({
        url: "upload/" + event.data.id ,
        type:"POST",
        data:formData,
        contentType:false,
        processData:false,
        cache:false,        
        success:function(resp){ 
            resp = JSON.parse(resp);   
            if (resp.hasOwnProperty('message')){
                $("#error-text").text(resp.message.text);
                $("#error-header").text(resp.message.header);
                $('#modal-error').openModal();
                $('#modal-error').on('click', '#error-btn', function(){  
                    window.location.replace(resp.redirect_url);
                })
                return;
            }
            reloadPNG(resp.id);
        },
        error:function(resp){
            if(resp.status == "403"){
                window.location.replace("/admin/login");
                return;
            }
            $("#error-text").text("Failed to update file. Please try again");
            $('#modal-error').openModal();
            
        },
        xhr:function(){
            myXhr = $.ajaxSettings.xhr();            
            if(myXhr.upload){                
                myXhr.upload.addEventListener('progress', function(evt){
                    if(evt.lengthComputable){
                        var ratio = (evt.loaded / evt.total) * 100;
                        $('#progress-' + event.data.id).width(ratio+"%")
                    }
                    
                }, false);
            }
            return myXhr;
        }
    });
    return false;
}

$(document).ready(function () {
    $('.modal-trigger').leanModal();
     $(".button-collapse").sideNav();
    $('#select-bg1920').on('change', {id:'bg1920'}, uploadPNG);
    $('#select-bg1024').on('change', {id:'bg1024'}, uploadPNG);
    $('#select-logo').on('change', {id:'logo'}, uploadPNG);
    
});