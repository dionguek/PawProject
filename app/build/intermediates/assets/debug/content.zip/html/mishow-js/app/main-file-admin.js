    
    var file_list = [];
    var curr_sort = true;
    var curr_field = 2;
    var defaultView = true;
    var total_gb = 0;
    var server_add = "https://192.168.10.1:8443/fs";
    //var server_add = "https://localhost:4000";

    function confirmDelete() {
        //$('#confirm-download').on('click', function(e) {
        var name = $('#delete-titl').html();
        console.log('confirm delete:' + name);

        $.ajax({ //Process the form using $.ajax()
            type        : 'POST', //Method type
            data        : name,
            url         : server_add + '/delete', //Your form processing file URL
            success     : function(data) {
                console.log(data);
                populate_file();
            },
        });
    }

    function fileDelete() {
        //$('#confirm-download').on('click', function(e) {
        var name = $('#file-titl').html();
        console.log('file delete:' + name);

        $.ajax({ //Process the form using $.ajax()
            type        : 'POST', //Method type
            data        : name,
            url         : server_add + '/delete', //Your form processing file URL
            success     : function(data) {
                console.log(data);
                populate_file();
            },
        });
    }


    function file_detail(indx, name) {
        var html = "<i>Size:</i> " + fileSize(file_list[indx].size) + "<br /><i>Date:</i> " + fileDate(file_list[indx].date) + "<br />";


        $('#file-titl').html(file_list[indx].name);
        $('#file-info').html(html);

        var butt = '<a href="#" class="btn waves-effect waves-green btn-flat modal-action modal-close">Cancel</a><a href="#" onclick="fileDelete()" class="btn waves-effect waves-green btn-flat modal-action modal-close">Delete</a>';
        $('#file-option').html(butt);

        $('#file-detail').openModal();
    }

    function delete_file(indx, name) {
        console.log("delete:(" + indx + ")" + name);

        var html = fileSize(file_list[indx].size) + "<br />" + fileDate(file_list[indx].date) + "<br />";

        $('#delete-titl').html(file_list[indx].name);
        $('#delete-info').html(html);
        $('#delete-confirm').openModal();
    }

        function tableHeading(view, field, sort) {

            var html = "";
            if(view) {
                $('#view-control').html('<a href="#" onclick="tableHeading(false, curr_field, false)"><img src="mishow-images/grid.png"/></a><img src="mishow-images/list.png"  style="opacity: 0.5;"/>');

                html += '<th style="text-align:center; width:35%"><a href="#" onclick="sort_onclick(0)">Title</a> <img id="im_name" src="" /></th>';
                html += '<th style="text-align:center; width:15%" class="hide-on-small-only"><a href="#" onclick="sort_onclick(1)">Size</a><img id="im_size" src="" /></th>';
                html += '<th style="text-align:center; width:30%" class="hide-on-small-only"><a href="#" onclick="sort_onclick(2)">Modified</a><img id="im_date" src="" /></th>';
                html += '<th style="text-align:center; width:20%"></th>';
                            
            } else {
                $('#view-control').html('<img src="mishow-images/grid.png" style="opacity: 0.5;"/><a href="#" onclick="tableHeading(true, curr_field, false)"><img src="mishow-images/list.png" /></a>');

                html += '<tr>';
                html += '<td colspan="6" style="text-align:right;">Sorted by:<img src="mishow-images/sort_bn.png" /><a href="#" onclick="sort_onclick(0)">Title<img id="im_name" src="" /></a><a href="#" onclick="sort_onclick(1)">Size<img id="im_size" src="" /></a><a href="#" onclick="sort_onclick(2)">Modified<img id="im_date" src="" /></a></td>';
                html += '</tr>';
            }

            defaultView = view;
            $('.document-head').html(html);

            fileSorting(field, sort);
        }

        function sort_onclick(indx) {
            console.log("sort_onclick:" + indx);
            fileSorting(indx, true);
        }

        function fileSize(size) {
            var size = size / 1024;
            var prefix = " KB";

            if(size > 1024) {
                size = size / 1024;
                prefix = " MB";
            }

            if(size > 1024) {
                size = size / 1024;
                prefix = " GB";
            }

            return size.toFixed(1) + prefix;
        }

        function fileDate(date) {
            return dateFormat(date, "mmmm dd, yyyy hh:MM");
        }

        function fileSorting(field, sort) {
            if (sort)
                curr_sort = ( (curr_field == field) ? !curr_sort : true );

            curr_field = field;
            //curr_sort = !curr_sort;
            var im = (curr_sort) ? 'mishow-images/sort_up.png' : 'mishow-images/sort_dn.png' ;
            $('#im_name').attr('src','mishow-images/sort_bn.png');
            $('#im_size').attr('src','mishow-images/sort_bn.png');
            $('#im_date').attr('src','mishow-images/sort_bn.png');
            $('#im_user').attr('src','mishow-images/sort_bn.png');
            switch(field) {
                case 0:
                    file_list.sort(function(a, b) {
                        return ( (curr_sort) ? (a.name.localeCompare(b.name)) : (b.name.localeCompare(a.name)) );
                    });

                    
                    $('#im_name').attr('src',im);
                break;

                case 1:
                    file_list.sort(function(a, b) {
                        return ( (curr_sort) ? (a.size-b.size) : (b.size-a.size) );
                   
                        //return (a.size-b.size);
                    });

                    $('#im_size').attr('src',im);
                break;

                case 2:
                    file_list.sort(function(a, b) {
                        return ( (curr_sort) ? (a.date.localeCompare(b.date)) : (b.date.localeCompare(a.date)) );
                        //return (a.date.localeCompare(b.date));
                    });

                    $('#im_date').attr('src',im);
                break;

                case 3:
                    file_list.sort(function(a,b) {
                        return ( (curr_sort) ? (a.user.localeCompare(b.user)) : (b.user.localeCompare(a.user)) );
                        //return (a.user.localeCompare(b.user));
                    });

                    $('#im_user').attr('src',im);
                break;
            }

            var indx = 0;
            var html = '';

            file_list.forEach(function (file) {
                var size = file.size / 1024;
                var prefix = " KB";

                if(size > 1024) {
                    size = size / 1024;
                    prefix = " MB";
                }

                if(size > 1024) {
                    size = size / 1024;
                    prefix = " GB";
                }

                if(defaultView) {
                    html += '<tr>';
                    html += '<td><a id="'+ file.indx +'" class="data-confirmation" onclick="fileDownload(\'' + indx + '\',\'' + file.name + '\')" download><div style="text-align:left; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><img src="mishow-images/file-16.png" />' + file.name + '</div></a></td>';
                    html += '<td class="td-center hide-on-small-only">' + fileSize(file.size) + '</td>';
                    html += '<td class="td-center hide-on-small-only">' + fileDate(file.date) + '</td>';

                    //html += '<td class="td-center"><button id="'+ file.indx +'" type="button" class="btn-bs btn-bs-danger btn-xs data-confirmation" onclick="delete_file('+ indx + ',\'' + file.name +'\')">delete</button></td>';
                    html += '<td class="td-center"><a class="waves-effect waves-light btn btn-color data-confirmation" onclick="delete_file('+ indx + ',\'' + file.name +'\')">delete</a></td>';


                    html += '</tr>';
                    indx++;
                } else {
                     if ((indx % 6) == 0) {
                        html += '<tr>';
                    }

                    html += '<td style="vertical-align: top; width:16.6%"><a id="'+ file.indx +'" class="data-confirmation" onclick="file_detail(\'' + indx + '\',\'' + file.name + '\')" download><div style="text-align:center; word-wrap: break-word;"><img src="mishow-images/file-64.png"/><br/>' + file.name + '</div></a></td>';

                    indx++;
                    if ((indx % 6) == 0) {
                        html += '</tr>';
                    }
                }
            });

            $('.document-body').html(html);
        }

        function populate_file() {
            $.ajax({ //Process the form using $.ajax()
                type      : 'POST', //Method type
                url       : server_add + '/fileList', //Your form processing file URL
                success   : function(data) {
                    console.log(data.size);
                    console.log(data.file);

                    total_gb = data.size / 1073741824;

                    var indx = 0;
                    var html = '';

                    $('#storage-progress-bar').css('width', (total_gb / 2)*100 + '%');   

                    //var s = total_gb + " GB (" + (total_gb / 2) + ") of 2 GB";
                    var s = ((total_gb / 2)*100).toFixed(1) + "% of 2.0 GB";
                    //$('#storage-progress-bar').html(s); 
                    $('#storage-label').html(s);

                    file_list = data.file;

                    tableHeading(defaultView, curr_field, false);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert(textStatus, errorThrown);
                }
            }); 
           
        }

        function browse_onClick() {
            $('#file-select').click();
        }

        $(document).ready(function () {
            populate_file();

            $('.btn-file :file').on('fileselect', function(event, numFiles, label) {
                var input = $(this).parents('.input-group').find(':text'),
                    log = numFiles > 1 ? numFiles + ' files selected' : label;
                
                if( input.length ) {
                    input.val(log);
                } else {
                    if( log ) alert(log);
                }                
            });

            $('#file-select').on('change', function(event) {

                //var input = $(this);
                var files = $(this).get(0).files;
                var label = $(this).val().replace(/\\/g, '/').replace(/.*\//, '');
                $('#file-label').text(label);

                //upload_onClick(); 

                console.log("upload file #" + files.length);
                //e.preventDefault();
                //var data = new FormData(jQuery('form')[0]);
                if (files[0].size > 2 * 1073741824){
                    alert("File can't exceed 2Gb");
                    return;
                }
                if (files[0].size + (total_gb * 1073741824) > 2 * 1073741824){
                    alert('Uploading this file will exceed available storage in RecoMedia. Please delete some files first.')
                    return;
                }
                if(files.length > 0){
                    //var i = setInterval(setInterval(function () {
                        // Log how much we saw in a couple seconds. 
                    //    console.log("uploading:" + meter.bytes);
                    //}, 1000));

                    var formData = new FormData(); 
                    formData.append("file", files[0], files[0].name);

                    $.ajax({ //Process the form using $.ajax()
                        type        : 'POST', //Method type
                        data        : formData,
                        contentType : false,
                        processData : false,
                        url         : server_add + '/upload', //Your form processing file URL
                        xhr         : function () {
                            $('#upload-progress').openModal();

                            var xhr = new XMLHttpRequest();

                            xhr.upload.addEventListener('progress', function(evt) {
                                if (evt.lengthComputable) {

                                    var percentComplete = evt.loaded / evt.total;
                                    percentComplete = parseInt(percentComplete * 100);

                                    //console.log(percentComplete);
                                    $('#upload-progress-bar').css('width', (percentComplete + '%'));   

                                    //$('.progress-bar').text(percentComplete + '%');
                                    //$('.progress-bar').width(percentComplete + '%');

                                    if (percentComplete === 100) {
                                        $('#upload-progress').closeModal();
                                    }
                                }

                            }, false);

                            return xhr;
                        },
                        success     : function(data) {
                            //console.log(data);
                            $("#file-select").val('');
                            $("#file-label").val('');
                            populate_file();
                        }
                        
                    });
                } else {
                    console.log("upload fail");
                    alert("Choose the file to upload.");
                }            
                //alert('file change:' + label);
                //input.trigger('fileselect', [numFiles, label]);                
            });

            $('.dropdown-button').dropdown();
            $('.modal-trigger').leanModal();
            $(".button-collapse").sideNav();
            $('.version').text('version ' + myversion);
        });
    