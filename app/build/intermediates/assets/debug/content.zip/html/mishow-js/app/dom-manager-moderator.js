var isProcessingButtonPress = false;

var CLIENT_TYPE = {
    PRESENTER: {
        value: 0
    },
    DISPLAY: {
        value: 1
    }
}

var CLIENT_STATUS = {
    ACTIVE: {
        value: 1
    },
    IDLE: {
        value: 2
    }
};

var CLIENT_STATUS_MAP = {
    1: "",
    2: "",
};

var PRESENTER_STATE = {
    IDLE: {
        value: 0
    },
    CONNECTING: {
        value: 1
    },
    STREAMING: {
        value: 2
    }
};

var DISPLAY_STATE = {
    NOT_SELECTED: {
        value: 0
    },
    SELECTED: {
        value: 1
    }
};
var DISPLAY_STATE_STATUS_MAP = {
    0: "Not selected",
    1: "Active",
};
var AUTH_FAILED = {
    WRONG_CREDENTIALS: {
        value: 0
    },
    ADMIN_ACTIVE: {
        value: 1
    }
}

var DOM = {
    CALLBACK: {
        LOGIN_REQUEST: "1",
        LOGOUT_REQUEST: "2",
        STREAM_REQUEST: "3",
        STOP_REQUEST: "4",
        ADD_TARGET_RECEIVER: "5",
        REMOVE_TARGET_RECEIVER: "6",
        SAVE_RESOLUTION: "7",
        QUERY_CURRENT_RESOLUTION: "8",
        SAVE_AP_CONF: "9",
        QUERY_RECEIVER_SENDER: "10",
        SAVE_WEB_VIEWER_MODE: "11",
        QUERY_CURRENT_WEB_VIEWER_MODE: "12"
    }
};

var MODE = {
    DEFAULT: {
        value: 0
    },
    SHOWCASE: {
        value: 1
    },
};

var MIN_WIDTH = 800;
var MIN_HEIGHT = 600;

function SenderUIHandler() {};

SenderUIHandler.prototype = {
    setSenderIdle: function ($sender) {
        $sender.removeClass('clicked');
        $sender.find(".status").text("");
        $sender.removeClass("z-depth-4");
        if (!$sender.parent().is('#sender-list')) {
            $sender.removeClass('active');
            $sender.find('.preview').fadeOut(600);
            $sender.find('.name').removeClass("name-no-preview");
        }
    },
    setSenderConnecting: function ($sender) {
        if ($sender.hasClass('clicked')) {
            $sender.find(".status").text("Please wait...");
            setTimeout(resetStatus, 5000, $sender);
        }
    },
    setSenderStreaming: function ($sender) {
        $sender.removeClass('clicked');
        $sender.addClass("z-depth-4");
        $sender.find(".status").text("Streaming...");

        if (!$sender.parent().is('#sender-list')) {
            $sender.addClass('active');
            $sender.find('.preview').fadeIn(600);
            $sender.find('.name').addClass("name-no-preview");
        }
    },
};


function executeQuery() {

    $.ajax({
        url: 'mishow-js/macadd.txt',
        dataType: "text",
        success: function (data) {
            // do something with the return value here if you like
            console.log(data);
            if (recomedia_id == "") {
                recomedia_id = data;
            } else if (recomedia_id == data) {
                console.error("same recomedia");
            } else {
                console.error("Changed recomedia");
                domManager.clearAll();
                $(domManager).trigger(DOM.CALLBACK.LOGOUT_REQUEST, "");
                $(".ui-base").hide();
                $("#loginframe").show();
                $('.button-collapse').hide()
                domManager.clearForms();
                recomedia_id = "";
                return;
            }
            setTimeout(executeQuery, 20000); // you could choose not to continue on failure...
        },
        error: function (jqXHR, textStatus, error) {
            console.error("Error recomedia:" + textStatus);
        },
        timeout: 5000,
    });
}

function ModeratorDomManager() {
    this.doc = document;
    this.currentDisplayRow = "";
    this.currentPresenterRow = "";
    this.sortableIn = 1;
    this.sendTimer = null;
    this.mode = MODE.DEFAULT;
    this.sender = new SenderUIHandler();
    var self = this;
}

ModeratorDomManager.prototype = {
    clearForms: function () {
        $("i").removeClass("active");
        $("label").removeClass("active");
        $("input").removeClass("valid");
        $("label").removeClass("active");
        $("input").removeClass("valid");
    },

    registerEventListeners: function () {
        var that = this;
        $(this.doc).on("click", "#loginbutton", function () {
            var username = $("#username").val();
            var password = $("#password").val();
            if (username != "" && password != "") {
                $("#loadingmodal").openModal();
                var data = {
                    username: username,
                    password: password
                };
                $(that).trigger(DOM.CALLBACK.LOGIN_REQUEST, data);
            }
            that.clearForms();
        });

        window.onbeforeunload = function (e) {
            if ($('#loginframe').css('display') != 'none') {
                return;
            }

            var confirmationMessage = "Have you saved your configuration?";

            (e || window.event).returnValue = confirmationMessage; //Gecko + IE
            return confirmationMessage; //Webkit, Safari, Chrome
        };

        $('#logoutmodal').on("click", "#logout", function () {
            $("#logoutmodal").closeModal();
            that.clearAll();
            $(that).trigger(DOM.CALLBACK.LOGOUT_REQUEST, "");
            $(".ui-base").hide();
            $("#loginframe").show();
            $('.button-collapse').hide()
            that.clearForms();
        });

        $('#password').keyup(function (e) {
            if (e.keyCode === 13) { //enter button
                $("#loginbutton").click();
            }
        });

        $(this.doc).on("click", '.modal-close', function (ev) {
            $('.modal').closeModal();
        });

        $('#unique-receiver-list').on("click", ".receiver", function () {
            var uid = $(this).attr('uid');
            var isStreaming = false;
            if (!uid) {
                console.error("Receiver: Can't determine uid");
            }

            if (isProcessingButtonPress) {
                return;
            }
            $('#unique-controls .sender').each(function () {
                if ($(this).hasClass('active')) {
                    //Materialize.toast('<span>Stop streaming first.</span>', 3500);
                    //console.log('dont allow click');
                    isStreaming = true;
                    return false;
                }
            });

            if (isStreaming)
                return;

            return; // Code below is for Mi-Showcase
            if (!$(this).hasClass("active")) {
                $(this).addClass('active');
                $(this).addClass('z-depth-2');
                $(this).find('.status').text(DISPLAY_STATE_STATUS_MAP[1]);

            } else {
                $(this).removeClass('active');
                $(this).removeClass('z-depth-2');
                $(this).find('.status').text(DISPLAY_STATE_STATUS_MAP[0]);
            }

        });

        $('#clear-config').click(function () {
            //It should stop all streams b4 clearing
            $(".sender-column").empty();
        });
        $('#save-config').click(function () {

            var configuration = [];
            $('.flex-container').each(function () {
                var receiverID = $(this).attr('id');
                if (!receiverID) {
                    //This is the hidden midisplay/mimeeting container
                    return;
                }
                var senders = that.getProfiles(escapeID(receiverID) + " .sender");
                var receivers = that.getProfiles(escapeID(receiverID) + " .receiver");
                var a_data = {};
                a_data['id'] = receiverID;
                a_data['senders'] = senders;
                a_data['receivers'] = receivers;
                configuration.push(a_data);
            });

            localStorage.setItem('showcase', JSON.stringify(configuration));
            Materialize.toast('<span>Configuration saved</span>', 3500);

        });

        $('#load-config').click(function () {
            var config = JSON.parse(localStorage.getItem('showcase'));

            if (!config || config.length == 0) {
                Materialize.toast('<span class=warning-text>Configuration not found.</span>', 3500);
                return;
            }
            $('.flex-container').each(function () {
                if (!$(this).find('#unique-receiver-list').length) {
                    $(this).remove();
                }
            });

            config.forEach(function (item) {
                var containerID = item['id'];

                var senders = item['senders'];
                var receivers = item['receivers'];
                if (receivers.length != 1) {
                    console.error("Error in no of receivers:" + receivers);
                    return;
                }
                that.createControlContainer(containerID.split('receiver-')[1]);

                receivers = receivers[0];
                that.createReceiver(receivers['name'],
                    receivers['uid'],
                    receivers['status'],
                    DISPLAY_STATE.SELECTED.value);

                senders.forEach(function (sender) {
                    that.populateContainerWithSender(sender['name'],
                        sender['uid'],
                        sender['status'],
                        sender['receiver'],
                        containerID);
                });

            });
            Materialize.toast('<span>Loaded successfully</span>', 3500);
            that.updateEventLister();
            $(that).trigger(DOM.CALLBACK.QUERY_RECEIVER_SENDER, '');
        });
    },

    updateEventLister: function () {
        var that = this;
        $('.sender-column').on("click", ".sender", function () {
            if (isProcessingButtonPress || $(this).hasClass('disconnected')) {
                return;
            }
            $(this).addClass('clicked');
            isProcessingButtonPress = true;
            var uid = $(this).attr('uid');
            var uidSelfAsReceiver = uid + ".RECV";
            var activeReceiversInContainer = [];
            var activeReceiversMinusSelf = [];
            var allReceiverInContainer = [];
            var buttonPressedTimeout = 2000;

            // Get all active receivers
            $(this).closest(".flex-container").find(".receiver-column .receiver").each(function () {
                var rcvUID = $(this).attr('uid');

                if ($(this).hasClass('active')) {
                    activeReceiversInContainer.push(rcvUID);
                    // Don't send to self
                    if (rcvUID != uidSelfAsReceiver) {
                        activeReceiversMinusSelf.push(rcvUID);
                    }
                }
                allReceiverInContainer.push(rcvUID);
            });

            // Current sender not streaming. So stop other stream if any
            if ($(this).hasClass('active') == false) {
                var playingSender = [];
                $(this).closest(".sender-column").find(".sender").each(function () {
                    if ($(this).hasClass('active')) {
                        playingSender.push($(this).attr('uid'));
                    }
                });

                function amIStreaming(uid, playingSender) {
                    if ($.inArray(uid, playingSender) > -1) {
                        return true;
                    }
                    return false;
                };

                var anotherMeStreaming = amIStreaming(uid, playingSender);

                // Check for any active streams in current group
                if (playingSender.length) {
                    var dataStop = {
                        presenterUid: playingSender,
                        receiverUid: activeReceiversInContainer
                    };
                    if (!anotherMeStreaming) {
                        $(that).trigger(DOM.CALLBACK.STOP_REQUEST, dataStop);
                    }
                }

                var dataSending = {
                    presenterUid: uid,
                    receiverUid: activeReceiversMinusSelf
                };

                if (anotherMeStreaming) {
                    buttonPressedTimeout = 100;
                    isProcessingButtonPress = true;
                    var sdr = new SenderUIHandler();
                    sdr.setSenderStreaming($(this));
                } else {
                    domManager.updateSenderState(uid, PRESENTER_STATE.CONNECTING, allReceiverInContainer, true);
                    $(that).trigger(DOM.CALLBACK.STREAM_REQUEST, dataSending);
                }
                domManager.allowButtonPress(buttonPressedTimeout);

                // Clear current container UI effects
                $(this).siblings().removeClass('active');
                $(this).siblings().children('.preview').hide().animate(300);
                $(this).siblings().children('.name').removeClass("name-no-preview");
                $(this).siblings().removeClass("z-depth-4");
                $(this).siblings().find(".status").text("");

            } else {
                //stop streaming
                var dataStop = {
                    presenterUid: [uid],
                    receiverUid: activeReceiversInContainer
                };

                $(that).trigger(DOM.CALLBACK.STOP_REQUEST, dataStop);
                domManager.allowButtonPress(buttonPressedTimeout);
            }
        });

        $(".flex-container, .receiver").disableSelection();

        $(".sender").hover(
            function () {
                $(this).addClass("z-depth-2");
            },
            function () {
                $(this).removeClass("z-depth-2");
            }
        );

        $('.control-container').sortable({
            items: ".flex-container",
            scroll: false,
            delay: 150,
            distance: 30,
            connectWith: ".flex-container",
            containment: ".ui-base",
        });


        $(".sortable").sortable({
            items: ".sender",
            helper: "clone",
            placeholder: "flex-item-highlight",
            scroll: false,
            delay: 150,
            distance: 30,
            connectWith: ".sortable ",
            receive: function (event, elem) {
                this.sortableIn = 1;
                if (elem.helper) {
                    elem.helper.removeClass("z-depth-2")
                        .removeAttr('style')
                        .hover(
                            function () {
                                $(this).addClass("z-depth-2");
                            },
                            function () {
                                $(this).removeClass("z-depth-2");
                            });
                }
                if (elem.item.hasClass("active")) {
                    elem.sender.sortable('cancel');
                }
            },
            over: function (event, elem) {
                $('.flex-container').removeClass('z-depth-5');
                $(this).closest('.flex-container').addClass("z-depth-3");
                that.sortableIn = 1;

            },
            out: function (event, elem) {
                $(this).closest('.flex-container').removeClass("z-depth-3");
                that.sortableIn = 0;

            },
            beforeStop: function (event, elem) {
                // don't remove sender that is currently streaming
                if (that.sortableIn == 0 && elem.item.hasClass('active') != true) {
                    elem.item.fadeOut('slow', function () {
                        elem.item.remove();
                    });
                }
            },
        });

        $(".item-list .sender").draggable({
            helper: "clone",
            scroll: false,
            cursor: "grab",
            connectToSortable: ".sortable",
            revert: "invalid",
            start: function (event, ui) {
                $('.flex-container').addClass('z-depth-5');
            },
            stop: function (event, ui) {
                $('.flex-container').removeClass('z-depth-5');
            }
        });
    },

    allowButtonPress: function (time) {
        setTimeout(function () {
            isProcessingButtonPress = false;
        }, time);
    },
    startStreaming: function (uid) {
        $(this).trigger(DOM.CALLBACK.STREAM_REQUEST, uid);
    },
    /* FOR MI_DISPLAY */
    licenseFailed: function () {
        $("#invalidlicensemodal").openModal();
        $(this).trigger(DOM.CALLBACK.LOGOUT_REQUEST, "");
    },
    loginFailed: function (failType) {

        $("#username").val("");
        $("#password").val("");
        $("#loadingmodal").closeModal();
        if (failType == AUTH_FAILED.WRONG_CREDENTIALS)
            $('#authmodal').openModal();
        else if (failType == AUTH_FAILED.ADMIN_ACTIVE)
            $("#authmodal-2").openModal();
        this.clearAll();
        $(".ui-base").hide();
        $("#loginframe").show();

    },
    loginSuccess: function () {
        $("#username").val("");
        $("#password").val("");
        $("#loginframe").hide();
        $(".ui-base").show();
        $("#loadingmodal").closeModal();
        $(".button-collapse").sideNav();
        $('#document-container').hide();
        $("#settingcontainer").hide();

        $('.brand-logo').show();
        $("#displaycontainer").hide();
        $(".ui-tab-container").hide();
        $('nav a.button-collapse').removeAttr('style');
        $("#nav-mobile").removeAttr('style');
        $("#nav-mobile li").removeAttr('style');

        $('#moderator-container').show();
        //executeQuery();
    },
    connectionError: function () {
        this.clearAll();
        $("#loadingmodal").closeModal();
        $("#connectmodal").openModal();
        $(".ui-base").hide();
        $("#loginframe").show();
    },
    clearAll: function () {
        $('.flex-container').each(function () {
            if ($(this).find('#unique-receiver-list').length) {
                $(this).find('#unique-receiver-list').empty();
                $(this).find('#unique-sender-list').empty();
            } else {
                $(this).remove();
            }
            $('#receiver-list').empty();
            $('#sender-list').empty();
            $('.button-collapse').hide();
            $("#nav-mobile").hide();
            $('.brand-logo').hide();
        });
        this.currentDisplayRow = "";
        this.currentPresenterRow = "";
    },
    updateBadges: function () {
        $("#sender-count").text($('#sender-list .sender').length);
        $("#receiver-count").text($('#receiver-list .receiver').length);
    },
    noSelectedReceiver: function () {
        Materialize.toast('<span class=warning-text>Warning!!!<a>&nbsp; Selection not valid.<a></span>', 5000);
    },
    appendIfNotExist: function (nodeTocheckUnique, nodeToAppend, uid, item) {
        var isExists = true;
        $(nodeTocheckUnique).each(function () {
            if ($(this).attr('uid') == uid) {
                isExists = false;
            }
        });

        if (isExists) {
            $(nodeToAppend).append(item);
        }
    },
    createReceiver: function (name, uid, status, state) {
        var profile = {
            name: this.getStandardName(name),
            uid: uid,
            status: status,
            state: state
        };
        //        console.log("createReceiver " +
        //            ' name:' + profile.name +
        //            ', uid:' + profile.uid +
        //            ', status:' + profile.status +
        //            ', state:' + DISPLAY_STATE_STATUS_MAP[profile.state]);

        var $receiverItem = $("<div/>", {
            "class": "flex-item receiver primary-color",
        }).append($("<div/>", {
            "class": "name",
            text: ' ' + profile.name,
        })).append($("<div/>", {
            "class": "status",
            text: DISPLAY_STATE_STATUS_MAP[state],
        }));
        $receiverItem.attr(profile);
        this.appendIfNotExist('#receiver-list .receiver', '#receiver-list',
            uid, $receiverItem.clone());

        $receiverItem.addClass('active');
        $receiverItem.addClass("z-depth-2");
        this.appendIfNotExist('#unique-receiver-list .receiver', '#unique-receiver-list',
            uid, $receiverItem.clone());

        $receiverItem.find('.name').addClass('fa fa-video-camera');
        this.appendIfNotExist(escapeID('receiver-' + uid) + ' .receiver', escapeID('receiver-' + uid) + ' .receiver-column',
            uid, $receiverItem.clone());

        this.updateEventLister();
    },

    //    returns true when item removed
    deleteItems: function (selector, uid) {
        var removed = false;
        $(selector).each(function () {
            if ($(this).attr('uid') == uid) {
                $(this).remove();
                removed = true;
            }
        });
        return removed;
    },

    removeReceiver: function (uid) {
        this.deleteItems("#receiver-list .receiver", uid);
        this.deleteItems("#unique-receiver-list .receiver", uid);
        this.updateReceiverList();
    },

    getProfiles: function (selector) {
        var profiles = [];
        $(selector).each(function () {
            var a_profile = {};
            $.each(this.attributes, function () {
                if (!this.specified)
                    return;
                if (this.name != 'class') {
                    a_profile[this.name] = this.value;
                }
            });
            a_profile['active'] = false;
            if ($(this).hasClass('active')) {
                a_profile['active'] = true;
            }
            profiles.push(a_profile);
        });
        return profiles;
    },
    getAllReceiverProfiles: function () {
        return this.getProfiles("#receiver-list .receiver");
    },

    updateReceiverList: function () {
        this.currentDisplayRow = "";
        var profiles = this.getAllReceiverProfiles();
        $("#receiver-list .receiver").remove();
        $("#unique-receiver-list .receiver").remove();
        for (var i = 0; i < profiles.length; i++) {
            this.createReceiver(profiles[i].name, profiles[i].uid, profiles[i].status, profiles[i].state);
        }
    },

    updateReceiverState: function (uid, state) {
        $("#receiver-list .receiver").each(function () {
            if ($(this).attr('uid') == uid) {
                $(this).attr('state', state);
                return false;
            }
        });
    },

    createOneSender: function (name, uid, status, receiver) {
        var profile = {
            name: this.getStandardName(name),
            uid: uid,
            status: status,
            receiver: receiver
        };

        var $senderItem = $("<div/>", {
            "class": "flex-item sender secondary-color",
        }).append($("<div/>", {
            "class": "preview",
        })).append($("<div/>", {
            "class": "name",
            text: profile.name,
        })).append($("<div/>", {
            "class": "status",
            text: CLIENT_STATUS_MAP[status],
        }));

        //        console.log("createSender " +
        //            ' name:' + profile.name +
        //            ', uid:' + profile.uid +
        //            ', status:' + CLIENT_STATUS_MAP[profile.status] +
        //            ', receiver:' + profile.receiver);
        $senderItem.attr(profile);
        return $senderItem;
    },

    populateContainerWithSender: function (name, uid, status, receiver, containerID) {
        var $senderItem = this.createOneSender(name, uid, status, receiver);
        $senderItem.addClass('disconnected');
        $(escapeID(containerID) + " .sender-column").append($senderItem);

        this.updateEventLister();
    },

    createSender: function (name, uid, status, receiver) {

        var $senderItem = this.createOneSender(name, uid, status, receiver);

        this.appendIfNotExist('#sender-list .sender', '#sender-list', uid, $senderItem.clone());
        this.appendIfNotExist('#unique-sender-list .sender', '#unique-sender-list', uid, $senderItem.clone());

        $(".sender-column .sender ").each(function () {
            if ($(this).attr('uid') == uid) {
                $(this).removeClass("disconnected");
            }
        });

        this.updateEventLister();
    },

    removeSender: function (uid) {
        var removedItems = false;
        var that = this;
        $("#unique-sender-list .sender").each(function () {
            if ($(this).attr('uid') == uid) {
                var name = $(this).attr('name');
                Materialize.toast('<span class=warning-text>Warning!!! <a>&nbsp;' + name + 'has left.<a></span>', 8000);
                return false;
            }
        });

        this.deleteItems("#sender-list .sender", uid);
        this.deleteItems("#unique-sender-list .sender", uid);

        //For mishowcase: Make color change
        $(".sender-column .sender ").each(function () {
            if ($(this).attr('uid') == uid) {
                $(this).addClass("disconnected");
                that.updateSenderState(uid, PRESENTER_STATE.IDLE, []); //revert sender to idle
            }
        });
        this.updateSenderList();
    },

    getAllSenderProfiles: function () {
        return this.getProfiles("#sender-list .sender");
    },

    updateSenderList: function () {
        this.currentPresenterRow = "";
        var profiles = this.getAllSenderProfiles();

        for (var i = 0; i < profiles.length; i++) {
            this.createSender(profiles[i].name, profiles[i].uid, profiles[i].status, profiles[i].receiver);
        }
    },

    //for showcase
    updateSenderState: function (uid, state, receiverUid, isCheckForClicked) {
        if (typeof isCheckForClicked === "undefined" || isCheckForClicked === null) {
            isCheckForClicked = false;
        }

        var sender = new SenderUIHandler();
        var hasTriggeredWarningMsg = false;
        $("#sender-list .sender, .sender-column .sender").each(function () {
            // check if update is for a different container
            if (receiverUid.length > 0) {
                if (receiverUid.length == 1) { //this is for mishowcase
                    receiverUid = receiverUid[0];
                }
                if (receiverUid[0] == '&') {
                    receiverUid = receiverUid.split('&')[1];
                }
                var flexUID = escapeID('receiver-' + receiverUid);
                //MAke sure that we are do not reset for NOT Mishowcase
                if ($(this).closest('#unique-sender-list').length == 0) {
                    //Don't update for another copy of sender in diff container
                    //else we're in non showcase mode
                    if (!$(this).closest(flexUID).length) {
                        return;
                    }
                }
            }

            if ($(this).attr('uid') != uid) {
                return;
            }

            switch (state) {
            case PRESENTER_STATE.IDLE:
                sender.setSenderIdle($(this));
                break;
            case PRESENTER_STATE.CONNECTING:
                sender.setSenderConnecting($(this));
                break;
            case PRESENTER_STATE.STREAMING:
                //check if it is the actual clicked item                    
                if (isCheckForClicked) {
                    if (!$(this).hasClass('clicked') && receiverUid) {
                        return;
                    }
                }
                sender.setSenderStreaming($(this));
                break;
            default:
                console.error("Unknown state");
            }
        });
    },

    createControlContainer: function (uid) {
        if (!uid || uid == undefined) {
            console.log('invalid uid' + uid);
            return;
        }
        var $container = $("<div/>", {
            "class": "flex-container z-depth-1 midisplay",
            'uid': uid,
            'id': 'receiver-' + uid,
        }).append($("<div/>", {
            "class": "receiver-column",
        })).append($("<div/>", {
            "class": "sender-column sortable",
        }));

        if ($(escapeID('receiver-' + uid)).length) //check uniqueness
            return;
        $('.control-container').append($container);
        this.updateEventLister();
    },

    acknowledgeSessionStarted: function (presenterUid, receiverUid, isCheckForClicked) {
        if (typeof isCheckForClicked === "undefined" || isCheckForClicked === null) {
            isCheckForClicked = false;
        }
        var that = this;
        $("#sender-list .sender, .sender-column .sender").each(function () {
            if ($(this).attr('uid') == presenterUid) {
                $(this).attr('receiver', $(this).attr('receiver') + "&" + receiverUid);
                $(this).attr('status', CLIENT_STATUS.ACTIVE.value);
                setTimeout(that.updateSenderState, 800, [presenterUid], PRESENTER_STATE.STREAMING, [receiverUid], isCheckForClicked);
                //return false;
            }
        });
    },

    acknowledgeSessionStopped: function (presenterUid, receiverUid) {
        var that = this;
        $("#sender-list, .sender-column").children('div').each(function () {
            if ($(this).attr('uid') == presenterUid) {
                var delimiter = "&";
                var holder = $(this).attr('receiver').split(delimiter);
                var newReceiverList = "";
                for (var i = 0; i < holder.length; i++) {
                    if (holder[i] != "" && holder[i] != receiverUid) {
                        newReceiverList = "&" + holder[i];
                    }
                }
                $(this).attr('receiver', newReceiverList);
                $(this).attr('status', CLIENT_STATUS.IDLE.value);
                that.updateSenderState(presenterUid, PRESENTER_STATE.IDLE, [receiverUid]);
                //                return false;
            }
        });

    },

    streamRequestFailed: function (presenterUid, displayUid, which) {
        console.error("streamRequestFailed NOT TESTED");
        var name = "";
        var isStreaming = false;
        if (which == CLIENT_TYPE.PRESENTER) {
            $(".ui-presenter-col").each(function (index) {
                if ($(this).data().uid == presenterUid) {
                    name = $(this).data().name;
                    return false;
                }
            });
        } else if (which == CLIENT_TYPE.DISPLAY) {
            $(".ui-display-col").each(function (index) {
                if ($(this).data().uid == displayUid) {
                    name = $(this).data().name;
                    if ($(this).data().receiver == "")
                        isStreaming = false;
                    return false;
                }
            });
        }
        $("#streamfailmodaltext").text("Unable to establish communication to " + name);
        $("#streamfailmodal").openModal();
        if (!isStreaming)
            this.updateSenderState(presenterUid, PRESENTER_STATE.IDLE);
    },

    setupSenderPair: function (displayUid, presenterUid) {
        var that = this;
        $(".flex-container").each(function () {
            if ($(this).attr('uid') == displayUid) {
                that.acknowledgeSessionStarted(presenterUid, displayUid);
                //                return false;
            }
        });
    },

    getStandardName: function (rawName) {
        var standardName = "";
        var delimiter = "%";
        var splitter = rawName.split(delimiter);
        var len = splitter.length;

        for (var i = 0; i < len; i++) {
            standardName = standardName + splitter[i] + " ";
        }
        return standardName;
    },
};

function escapeID(id) {
    return "#" + id.replace(/(:|\.|\[|\]|,)/g, "\\$1");
}

function resetStatus($flexItem) {
    if ($flexItem.find(".status").text() == "Please wait...") {
        $flexItem.removeClass('clicked');
        $flexItem.find(".status").text("");
        $flexItem.removeClass("z-depth-4");
        $flexItem.removeClass('active');
        $flexItem.find('.preview').fadeOut(600);
        $flexItem.find('.name').removeClass("name-no-preview");
    }
}