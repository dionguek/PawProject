function DomManager() {
    this.doc = document;
    var self = this;
}

DomManager.prototype = {
    clearForms: function () {
        $("i").removeClass("active");
        $("label").removeClass("active");
        $("input").removeClass("valid");
        $("#username").val("");
        $("#password").val("");
    },

    registerEventListeners: function () {
        var that = this;
        
        // validate signup form on keyup and submit
		$("#ap-form").validate({
			rules: {				
				inputpassword: {
					required: true,
					minlength: 8
				},
				confirm_ap_password: {
					required: true,
					equalTo: "#inputpassword"
				},
                inputssid: {
					required: true,
					minlength: 5,
                    pattern: /^[a-zA-Z0-9-_]+$/
				},
			},
			messages: {
				inputpassword: {
					required: "Please provide a password",
					minlength: "Your password must be at least 8 characters"
				},
				confirm_ap_password: {
					required: "Please enter the same password as above",
					equalTo: "Please enter the same password as above"
				},
				inputssid: {
					required: "Please provide an id",
					minlength: "Your password must be at least 5 characters",
                    pattern: "Invalid character"
				},
			}
		});
        
        $("#admin-password-form").validate({
			rules: {				
				adminpassword: {
					required: true,
					minlength: 8
				},
				confirm_adminpassword: {
					required: true,
					equalTo: "#adminpassword"
				},				
			},
			messages: {
				adminpassword: {
					required: "Please provide a password",
					minlength: "Your password must be at least 8 characters long"
				},
				confirm_adminpassword: {
					required: "Please re-enter the same password as above",
					equalTo: "Please enter the same password as above"
				},
			}
		});
        
        $(this.doc).on("click", "#loginbutton", function () {
            var username = $("#username").val();
            var password = $("#password").val();
            
            if (username != "" && password != "") {
                var data = {
                    username: username,
                    password: password
                };
                doPostData('login', data);
            }
        });

        window.onbeforeunload = function (e) {
            if ($('#loginframe').css('display') != 'none') {
                return;
            }

            var confirmationMessage = "Have you saved your configuration?";

            (e || window.event).returnValue = confirmationMessage; //Gecko + IE
            return confirmationMessage; //Webkit, Safari, Chrome
        };

        
        $('#logoutmodal').on("click", "#logout", function () {
            $("#logoutmodal").closeModal();
            postLogOut();
        });

        $('#nav-settings, #nav-settings-mobile').click(function () {
            $('#nav-moderator, #nav-moderator-mobile').show();
            $('#nav-settings, #nav-settings-mobile').hide();
            $('#nav-documents, #nav-documents-mobile').show();
            $('#settingcontainer').show();
            $('#moderator-container').hide();
            $('#document-container').hide();
        });

        $('#nav-moderator, #nav-moderator-mobile').click(function () {
            $('#nav-moderator, #nav-moderator-mobile').hide();
            $('#nav-settings, #nav-settings-mobile').show();
            $('#nav-documents, #nav-documents-mobile').show();
            $('#settingcontainer').hide();
            $('#moderator-container').show();
            $('#document-container').hide();
        });

        $('#nav-documents, #nav-documents-mobile').click(function () {
            $('#nav-moderator, #nav-moderator-mobile').show();
            $('#nav-settings, #nav-settings-mobile').show();
            $('#nav-documents, #nav-documents-mobile').hide();
            $('#settingcontainer').hide();
            $('#moderator-container').hide();
            $('#document-container').show();
        });

        $('#password').keyup(function (e) {
            if (e.keyCode === 13) { //enter button
                $("#loginbutton").click();
            }
        });

        $(this.doc).on("click", '.modal-close', function (ev) {
            $('.modal').closeModal();
        });

        $(this.doc).on("click", "#savebutton", function (ev) {
            var res = $("#resdropdown option:selected").text();
            var mode = "";
            if ($('#wbv-on').prop("checked")) {
                mode = "on";
            } else if ($('#wbv-off').prop("checked")) {
                mode = "off";
            } else {
                alert("Error getting selected options");
                return;
            }
            var data = {'resolution':res, 'webview_mode':mode};
            doPostData("resolution", data);
        });

        $(this.doc).on("click", "#apsavebutton", function () {
            
            //force validation
            $("#ap-password").validate().element("#inputssid");
            if ($("#inputssid-error").text().length){
                console.error('ssid validation failed');
                return;
            }
            
            var ssid = $("#inputssid").val();
            var password = "";
            if (($("#securitydiv option:selected").val()) == "WPA2-Personal") {
                password = $("#inputpassword").val();
                
                $("#ap-password").validate().element("#inputpassword")
                $("#ap-password").validate().element("#confirm_ap_password");                
                
                if ($("#confirm_ap_password-error").text().length ||                     
                    $("#ap-password-error").text().length){
                    console.error('password validation failed');
                    return;
                }
            } 

            var freq = "";
            var channel = "";
            if ($('#g').prop("checked")) {
                freq = "g";
                channel = $("#channel1div option:selected").text();
            } else if ($('#a').prop("checked")) {
                freq = "a";
                channel = $("#channel2div option:selected").text();
            }
            var data = {'hw_mode': freq, 'channel':channel, 'ssid':ssid, 'wpa_passphrase':password}
            console.log(data)
            doPostData('ap', data);
            
        });
        
        $(this.doc).on("click", "#savePasswordbutton", function () {
            //force validation
            $("#admin-password-form").validate().element("#adminpassword");
            $("#admin-password-form").validate().element("#confirm_adminpassword");
            
            if ($("#password-error").text().length || 
                $("confirm_adminpassword-error").text().length){
                return;
            }
            
            var password = $("#adminpassword").val();
            var data = {'password':password}
            doPostData('password', data);               
        });
        
        $("#securitydiv").change(function () {
            if ($("#securitydiv option:selected").val() == "WPA2-Personal") {
                $("#ap-password").show();
                $("#inputpassword").show();
            } else {
                $("#ap-password").hide();
                $("#inputpassword").hide();
                $("#inputpassword").val("");
            }
        });
        $("#g").click(function () {
            $("#channel1div").parent(".select-wrapper").show();
            $("#channel2div").parent(".select-wrapper").hide();

        });
        $("#a").click(function () {
            $("#channel1div").parent(".select-wrapper").hide();
            $("#channel2div").parent(".select-wrapper").show();

        });
	
        $(this.doc).on("click", "#activateLicence", function () {

            var key = $("#licencekey").val();
            data = {'key':key}
            doPostData('key', data);            
        });
    },


    /* FOR MI_DISPLAY */
    licenseFailed: function () {
        $("#invalidlicensemodal").openModal();
    },
    
    loginFailed: function (failType) {
        $("#username").val("");
        $("#password").val("");
        $("#loadingmodal").closeModal();
        if (failType == AUTH_FAILED.WRONG_CREDENTIALS)
            $('#authmodal').openModal();
        else if (failType == AUTH_FAILED.ADMIN_ACTIVE)
            $("#authmodal-2").openModal();
        this.clearAll();
        $(".ui-base").hide();
        $("#loginframe").show();

    },
    loginSuccess: function () {
        $("#username").val("");
        $("#password").val("");
        $("#loginframe").hide();
        $(".ui-base").show();
        $("#loadingmodal").closeModal();
        $(".button-collapse").sideNav();
        $('#nav-settings, #nav-settings-mobile').show();
        $('#nav-documents, #nav-documents-mobile').show();
        $('#document-container').hide();
        $("#settingcontainer").hide();
        $("#nav-moderator").hide();
        $("#nav-moderator-mobile").hide();
        $('.brand-logo').show();
        $("#displaycontainer").hide();
        $(".ui-tab-container").hide();
        $('nav a.button-collapse').removeAttr('style');
        $("#nav-mobile").removeAttr('style');
        $("#nav-mobile li").removeAttr('style');
        $('#moderator-container').show();
//        executeQuery();
    },

    updateCurrentResolution: function (resolution) {

        $("#resdropdown").children().slice(1).remove();
        var splitted = resolution.split("_");

        var resList = splitted[1].split(" ");
        for (var i = 1; i < resList.length; i++) {
            if (resList[i] != " " && resList[i].length != 0) {
                if (this.filterOut(resList[i])) {
                    continue
                }
                var option = $("<option></option>");
                $(option).attr("value", i.toString());
                $(option).text(resList[i]);

                if (resList[i] == splitted[0]) {
                    $(option).attr("selected", "");
                }
                $(option).appendTo("#resdropdown");
            }
        }
        $('#resdropdown').material_select();
    },

    updateCurrentWebViewerMode: function (mode) {
        if (mode == "on") {
            $("#wbv-on").prop("checked", true);
        } else if (mode == "off") {
            $("#wbv-off").prop("checked", true);
        }

    },

    populateAPConf: function (apConf) {
        var splitConf = apConf.split(" ");
        for (var i = 0; i < splitConf.length; i++) {
            var split2 = splitConf[i].split("=");
            if (split2.length > 1) {
                if (split2[0] == "channel") {
                    var channelUsed = split2[1];
                    if (parseInt(channelUsed) <= 11) {
                        $('#channel1div option').filter(function () {
                            return $(this).text() == channelUsed;
                        }).prop("selected", true);
                        $("#channel1div").change();
                    } else {
                        $('#channel2div option').filter(function () {
                            return $(this).text() == channelUsed;
                        }).prop("selected", true);
                        $("#channel2div").change();
                    }
                }
                if (split2[0] == "hw_mode") {
                    if (split2[1] == "a") {
                        $("#a").prop("checked", true);
                    } else if (split2[1] == "g") {
                        $("#g").prop("checked", true);
                    }

                }
                if (split2[0] == "ssid") {
                    $("#inputssid").val(split2[1]);
                }
                if (split2[0] == "wpa_passphrase") {
                    $("#inputpassword").val(split2[1]);
                    $('#securitydiv option').filter(function () {
                        return $(this).text() == "WPA2-Personal";
                    }).prop("selected", true);
                    $("#securitydiv").change();
                }
            }
        }
        if ($("#securitydiv option:selected").val() == "WPA2-Personal") {
            $("#ap-password").show();
            $("#inputpassword").show();
        } else {
            $("#ap-password").hide();
            $("#inputpassword").hide();
            $("#inputpassword").val("");
        }

        $('select').material_select();
        if ($("#a").prop("checked")) {
            $("#channel2div").parent(".select-wrapper").show();
            $("#channel1div").parent(".select-wrapper").hide();

        } else if ($("#g").prop("checked")) {
            $("#channel2div").parent(".select-wrapper").hide();
            $("#channel1div").parent(".select-wrapper").show();
        }
    }
};


function escapeID(id) {
    return "#" + id.replace(/(:|\.|\[|\]|,)/g, "\\$1");
}

function resetStatus($flexItem) {
    if ($flexItem.find(".status").text() == "Please wait...") {
        $flexItem.removeClass('clicked');
        $flexItem.find(".status").text("");
        $flexItem.removeClass("z-depth-4");
        $flexItem.removeClass('active');
        $flexItem.find('.preview').fadeOut(600);
        $flexItem.find('.name').removeClass("name-no-preview");
    }
}
