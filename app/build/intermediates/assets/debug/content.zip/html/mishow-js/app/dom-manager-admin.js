

function DomManager() {
    this.doc = document;
    var self = this;
}

DomManager.prototype = {
    clearForms: function () {
        $("i").removeClass("active");
        $("label").removeClass("active");
        $("input").removeClass("valid");
        $("#username").val("");
        $("#password").val("");
    },

    registerEventListeners: function () {
        var that = this;
        
        $(this.doc).on("click", "#loginbutton", function () {
            var username = $("#username").val();
            var password = $("#password").val();
            
            if (username != "" && password != "") {
                var data = {
                    username: username,
                    password: password
                };
                doPostData('login', data);
            }
        });
        $(this.doc).on("click", "#activateLicence", function () {

            var key = $("#licencekey").val();
            data = {'key':key}
            doPostData('key', data);            
        });

        window.onbeforeunload = function (e) {
            if ($('#loginframe').css('display') != 'none') {
                return;
            }

            var confirmationMessage = "Have you saved your configuration?";

            (e || window.event).returnValue = confirmationMessage; //Gecko + IE
            return confirmationMessage; //Webkit, Safari, Chrome
        };
        
        $('#password').keyup(function (e) {
            if (e.keyCode === 13) { //enter button
                $("#loginbutton").click();
            }
        });

        $(this.doc).on("click", '.modal-close', function (ev) {
            $('.modal').closeModal();
        });
        
        $('#logoutmodal').on("click", "#logout", function () {
            $("#logoutmodal").closeModal();
            postLogOut();
        });
    },


    licenseFailed: function () {
        $("#invalidlicensemodal").openModal();
        $(this).trigger(DOM.CALLBACK.LOGOUT_REQUEST, "");
    },
    
    loginFailed: function (failType) {
        $("#username").val("");
        $("#password").val("");
        $("#loadingmodal").closeModal();
        if (failType == AUTH_FAILED.WRONG_CREDENTIALS)
            $('#authmodal').openModal();
        else if (failType == AUTH_FAILED.ADMIN_ACTIVE)
            $("#authmodal-2").openModal();
        this.clearAll();
        $(".ui-base").hide();
        $("#loginframe").show();
    },
    
    loginSuccess: function () {
        $("#username").val("");
        $("#password").val("");
        $("#loginframe").hide();
        $(".ui-base").show();
        $("#loadingmodal").closeModal();
        $(".button-collapse").sideNav();
        $('#nav-settings, #nav-settings-mobile').show();
        $('#nav-documents, #nav-documents-mobile').show();

        if (true) { //should be for recoshow only
            $('#document-container').hide();
            $("#settingcontainer").hide();
            $("#nav-moderator").hide();
            $("#nav-moderator-mobile").hide();
            $('.brand-logo').show();
            $("#displaycontainer").hide();
            $(".ui-tab-container").hide();
            $('nav a.button-collapse').removeAttr('style');
            $("#nav-mobile").removeAttr('style');
            $("#nav-mobile li").removeAttr('style');
        }
        $('#moderator-container').show();
    },
};
