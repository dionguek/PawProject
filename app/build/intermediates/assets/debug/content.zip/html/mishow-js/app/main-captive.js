/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


window.onload = function () {
    registerEventListener();
};

function registerEventListener() {
    var doc = document;
    var AppName = $(doc).attr("title");
    $(doc).on("click", "#download-btn", function () {

        var platform = window.navigator.platform;
        if (platform == "Win32" || platform == "Win64") {
            var url = 'http://192.168.10.1/mishow-installers/setup_' + AppName + '.exe';
            window.location.assign(url);
        } else if (platform == "MacPPC" || platform == "MacIntel") {
            var url = 'http://192.168.10.1/mishow-installers/setup_' + AppName + '.dmg';
            window.location.assign(url);
        } else
            alert("We currently only support Windows and Mac OSX client");
    });

    $(doc).on("click", "#admin-btn", function () {
        window.location = "https://192.168.10.1:8443/admin/login";
    });
    
    $(doc).on("click", "#moderator-btn", function () {
        window.location = "https://192.168.10.1:8443/";
    });

    $(doc).on("click", "#webviewer-btn", function () {
        window.location = "http://192.168.10.1/viewer/";
    });
    
}