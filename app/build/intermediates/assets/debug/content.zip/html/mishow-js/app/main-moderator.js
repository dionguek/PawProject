/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var CONTROLLER_IP = "192.168.10.1";
var activeReceiverFromBefore = [];

/* FOR MI_DISPLAY */
var reconnectFlag = false;
var usernameHolder = "";
var passwordHolder = "";
var errorAlreadyTriggered = false;

window.onload = function () {
    mishowAdmin = new MishowAdmin();
    domManager = new ModeratorDomManager();

    initEventListener();
    domManager.registerEventListeners();
    domManager.updateBadges();
    mishowAdmin.connect(CONTROLLER_IP, mishowAdminCallback);
};

function initEventListener() {

    $(domManager).on(DOM.CALLBACK.LOGIN_REQUEST, function (ev, data) {

        usernameHolder = data.username;
        passwordHolder = data.password;


            if (mishowAdmin.getConnectionState() == 3) {
                reconnectFlag = true;
                mishowAdmin.connect(CONTROLLER_IP, mishowAdminCallback);
            }

            if (!reconnectFlag)
                mishowAdmin.authenticate(usernameHolder, passwordHolder);

    });

    $(domManager).on(DOM.CALLBACK.LOGOUT_REQUEST, function (ev, data) {
        errorAlreadyTriggered = true;
        mishowAdmin.disconnect();
    });

    $(domManager).on(DOM.CALLBACK.STREAM_REQUEST, function (ev, data) {

        receivers = data.receiverUid;
        sender = data.presenterUid;
        if (receivers.length == 0) {
            domManager.noSelectedReceiver();
            domManager.updateSenderState(sender, PRESENTER_STATE.IDLE, receivers);
        } else {
            for (var i = 0; i < receivers.length; i++) {
                var receiver = receivers[i];
                console.log("CALLBACK.STREAM_REQUEST  from " + sender + " -> " + receiver);
                setTimeout(stream, 500 + (i * 200), sender, receiver);
            }
        }
    });
    $(domManager).on(DOM.CALLBACK.STOP_REQUEST, function (ev, data) {
        var receivers = data.receiverUid.reduce(function (a, b) {
            if (a.indexOf(b) < 0) a.push(b);
            return a;
        }, []);
        var presenterUid = data.presenterUid.reduce(function (a, b) {
            if (a.indexOf(b) < 0) a.push(b);
            return a;
        }, []);
        for (var i = 0; i < receivers.length; i++) {
            if (receivers[i] != "") {

                var receiverUid = receivers[i];
                setTimeout(stop, 50 + (i * 100), presenterUid, receiverUid);
                console.log("CALLBACK.STOP_REQUEST  from " + presenterUid + " -> " + receiverUid);
            }
        }
    });


    $(domManager).on(DOM.CALLBACK.SAVE_AP_CONF, function (ev, data) {
        mishowAdmin.saveAPConf(data);
        alert("Restarting WiFi service... Please reconnect to media box");
    });

    $(domManager).on(DOM.CALLBACK.QUERY_RECEIVER_SENDER, function (ev, data) {
        mishowAdmin.getReceiverList();
    });
}

function stream(presenterUid, displayUid) {
    mishowAdmin.stream(presenterUid, displayUid);
}

function stop(presenterUid, displayUid) {
    mishowAdmin.stop(presenterUid, displayUid);
}

function mishowAdminCallback(msgType, data1, data2, data3) {
    switch (msgType) {
    case mishowAdmin.CALLBACK_CONNECTED:
        if (reconnectFlag)
            mishowAdmin.authenticate(usernameHolder, passwordHolder);
        
        break;

    case mishowAdmin.CALLBACK_ERROR:

        domManager.connectionError();
        errorAlreadyTriggered = true;
        reconnectFlag = false;
        break;

    case mishowAdmin.CALLBACK_CLOSED:

        activeReceiverFromBefore = [];
        if (!errorAlreadyTriggered) {
            domManager.connectionError();
        }
        errorAlreadyTriggered = false;
        reconnectFlag = false;
        break;

    case mishowAdmin.CALLBACK_REQUERY_LIST:
        mishowAdmin.getReceiverList();
        break;
    case mishowAdmin.CALLBACK_AUTHENTICATION:
        if (data1 == mishowAdmin.AUTH_SUCCESS) {
            if (isMobile.any()) {
                mishowAdmin.registerAsMobile();
            }
            domManager.loginSuccess();
            mishowAdmin.getReceiverList();
        } else if (data1 == mishowAdmin.AUTH_FAILED) {
            domManager.loginFailed(AUTH_FAILED.WRONG_CREDENTIALS);
            
            mishowAdmin.disconnect();
            errorAlreadyTriggered = true;
        } else if (data1 == mishowAdmin.AUTH_OCCUPIED) {
            domManager.loginFailed(AUTH_FAILED.ADMIN_ACTIVE);
            mishowAdmin.disconnect();
            errorAlreadyTriggered = true;
        }
        break;


    case mishowAdmin.CALLBACK_RECEIVER_LIST:
        var total = data1.length;
        activeReceiverFromBefore = [];
        for (var i = 0; i < total; i++) {
            if (data3[i] == CLIENT_STATUS.ACTIVE.value) {
                console.log('CALLBACK_RECEIVER_LIST:' + data2[i])
                activeReceiverFromBefore.push(data2[i]);
            }
            domManager.createControlContainer(data2[i]);
            domManager.createReceiver(data1[i], data2[i], data3[i], DISPLAY_STATE.SELECTED.value);
            domManager.updateBadges();
        }
        mishowAdmin.getSenderList();
        break;


    case mishowAdmin.CALLBACK_SENDER_LIST:
        var total = data1.length;
        for (var i = 0; i < total; i++) {
            domManager.createSender(data1[i], data2[i], data3[i], "");
            domManager.updateBadges();
        }
        if (activeReceiverFromBefore.length > 0) {
            var len = activeReceiverFromBefore.length;
            for (var i = 0; i < len; i++) {
                mishowAdmin.getSenderPair(activeReceiverFromBefore[i]);
            }
        }
        break;

    case mishowAdmin.CALLBACK_NEW_SENDER:
        domManager.createSender(data1, data2, data3, "");
        domManager.updateBadges();
        break;

    case mishowAdmin.CALLBACK_SENDER_LEAVE:
        domManager.removeSender(data2);
        domManager.updateBadges();
        break;

    case mishowAdmin.CALLBACK_NEW_RECEIVER:
        domManager.createControlContainer(data2);
        domManager.createReceiver(data1, data2, data3, DISPLAY_STATE.SELECTED.value);
        domManager.updateBadges();

        break;

    case mishowAdmin.CALLBACK_RECEIVER_LEAVE:
        domManager.removeReceiver(data2);
        domManager.updateBadges();
        break;

    case mishowAdmin.CALLBACK_SENDER_CHANGE_STATUS:
        break;

    case mishowAdmin.CALLBACK_RECEIVER_CHANGE_STATUS:
        break;

    case mishowAdmin.CALLBACK_STREAM_ACK:
        domManager.acknowledgeSessionStarted(data1, data2, true);
        break;

    case mishowAdmin.CALLBACK_STOP_ACK:

        domManager.acknowledgeSessionStopped(data1, data2);
        break;

    case mishowAdmin.CALLBACK_STREAM_SENDER_FAILED:
        domManager.streamRequestFailed(data1, data2, CLIENT_TYPE.PRESENTER);
        break;

    case mishowAdmin.CALLBACK_STREAM_RECEIVER_FAILED:
        domManager.streamRequestFailed(data1, data2, CLIENT_TYPE.DISPLAY);
        break;

    case mishowAdmin.CALLBACK_SENDER_PAIR:
        console.log("Sender Pair : " + data1 + " : " + data2);
        domManager.setupSenderPair(data1, data2);
        break;

    case mishowAdmin.CALLBACK_SEND_TO_SELF:
        var receiverUID = [data1 + '.RECV']; //NOTE: Assumes UID = MACADDRESS +'.RECV'. True for windows
        domManager.updateSenderState(data1, PRESENTER_STATE.IDLE, receiverUID);
        break;

    case mishowAdmin.CALLBACK_SCREEN_SETTING:
        break;

    case mishowAdmin.CALLBACK_NEW_SCREEN_SETTING:
        break;

        /* FOR MI-DISPLAY */
    case mishowAdmin.CALLBACK_LICENSE_ERROR:
        domManager.licenseFailed();
        break;
    }
}

var isMobile = {
    Android: function () {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function () {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function () {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function () {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function () {
        return navigator.userAgent.match(/IEMobile/i);
    },
    any: function () {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};