/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!String.prototype.includes) {
  String.prototype.includes = function(search, start) {
    'use strict';
    if (typeof start !== 'number') {
      start = 0;
    }
    
    if (start + search.length > this.length) {
      return false;
    } else {
      return this.indexOf(search, start) !== -1;
    }
  };
}

window.onload = function () {

    domManager = new DomManager();
    domManager.registerEventListeners();

//    window.confirmOnPageExit = postLogOut;
//    window.onbeforeunload = postLogOut;
    
};

var postLogOut = function(e){
    $.ajax({
          type: "POST",
          url: "logout",
          data: "",
          dataType: "text"
        }).done(function(data) {
            data = JSON.parse(data);    
            redirect_path = data['redirect_url']
            if(redirect_path != ''){                                  
                window.location.replace(redirect_path);
                
            }
        });
}	
var confirmOnPageExit = function (e) 
{
    if (window.location.href.includes('login')){
        return;
    }
    postLogOut();
};

function doPostData(url, data){
        
        $.ajax({
          type: "POST",
          url: url,
          data: data,
          error: function(xhr, statusText, errorThrown){
              if (xhr.status == 403){
                $('#modal-info').openModal();
                $('#info-text').text("Please login again");
                $('#info-header').text("Session expired");
                $('#modal-info').on('click', '#info-btn', function(){
                    console.error("postlogout")
                    postLogOut();
                })
                return;
              }
          },
          dataType: "text"
        }).done(function(data, statusText, xhr) {
            var data = JSON.parse(data);
            if (data.message != ''){
                domManager.clearForms();
                $('#modal-info').openModal();
                $('#info-text').text(data.message.text);
                $('#info-header').text(data.message.header);
                $('#modal-info').on('click', '#info-btn', function(){
                    window.location.replace(data['redirect_url']);
                })
                return;
            }
            
            if(data.redirect_path != ''){                  
                window.location.replace(data['redirect_url']);
            }
        });
}