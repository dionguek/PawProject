$(document).ready(function () {
    var slide = new SlideHandler();
    slide.registerEventListeners();
    slide.start();
    initialiseSlide();
});

initialiseSlide = function () {
    $('#image-slide').attr('src', "../static/mishow-images/background.png");
    $('.fixed-action-btn').hide();
}

parseString = function (nm, parseChar) {
    var s = nm.toString().replace(/\\/g, '/');
    s = s.substring(s.lastIndexOf('/') + 1, s.lastIndexOf(parseChar));
    return s.replace(/[?#].+$/, '');
}

getfilename = function (nm) {
    return parseString(nm, ')');
}

getPage = function (nm) {
    return parseString(nm, '.');
}

var SlideHandler = function () {
    this.socket = null;
    this.updateToLatest = true;
    this.first = null;
    this.current = null;
    this.latest = null;
    this.path = null;
    this.transitioning = false;
    this.cache_session = "NAISS";
    this.isFirst = false;
    this.delay = 0;
};

SlideHandler.prototype.start = function () {
    var url = "ws://" + location.host + "/ws";
    var that = this;
    this.socket = new WebSocket(url);
    this.socket.onmessage = function (event) {
        that.parseMessage(JSON.parse(event.data));
    }
    this.socket.onclose = function(){
        //try to reconnect in 4 seconds
        that.socket = null;
        console.error("Socket closed");
        setTimeout(function(){that.start()}, 4000);
    };
    this.socket.onerror = function(err) {
        console.error('WeSocket error: ', err.message, 'Closing socket')
        that.socket.close()
  };
};

SlideHandler.prototype.parseMessage = function (message) {
    if (!('first' in message) || !('latest' in message) || !('path' in message)) {
        console.error('missing key:' + JSON.stringify(message));
        return;
    }

    if (parseInt(message['first']) == 0) {
        initialiseSlide();
        return;
    }

    $('.fixed-action-btn').show();
    this.first = message['first'];
    this.latest = message['latest'];
    this.path = message['path'];
    this.cache_session = message['random'];
    if (message['delay'] != -1) {
        this.delay = message['delay'];
    }

    if (parseInt(this.latest) == 1) {

        this.setCurrent(1, this.delay);
        this.isFirst = true;

        $("#previous").addClass('disabled');
        $("#next").addClass('disabled');
        $("#first").addClass('disabled');
        $("#last").addClass('disabled');
        return;
    }
    
    if(this.current!=1){
        $("#previous").removeClass('disabled');
        $("#first").removeClass('disabled');
    }
    if (this.updateToLatest == true) {
        this.setCurrent(this.latest, this.delay);
        $("#next").addClass('disabled');
        $("#last").addClass('disabled');
        $("#last").removeClass('new-slide-accent');
    } else {
        $("#last").addClass('new-slide-accent');
    }

    this.isFirst = true;
};

SlideHandler.prototype.setCurrent = function (slideNo, delay) {
    this.current = slideNo;
    this.updateSlide(slideNo, delay);
};

SlideHandler.prototype.sendMessage = function (message) {
    updater.socket.send(JSON.stringify(message));
};


SlideHandler.prototype.updateSlide = function (slideNo, delay) {
    if (this.transitioning == true) {
        return;
    }
    this.transitioning = true;
    var newSlide = "slides/" + this.path + "/" + slideNo + ".jpg" + "?v=" + this.cache_session;
    var that = this;
    setTimeout(function () {
        $('#image-slide').addClass('fade-out');
    }, (delay * 1000));

    setTimeout(function () {
        $('#image-slide').attr('src', newSlide);
        that.transitioning = false;
        $('#image-slide').removeClass('fade-out');
    }, 800 + (delay * 1000));
};


SlideHandler.prototype.registerEventListeners = function () {
    var that = this;
    var file = $('#image-slide').attr('src');

    that.current = getfilename(file);
    that.latest = that.current;
    that.first = that.current;

    $("#previous").click(function () {
        that.updateToLatest = false;
        slideNo = (parseInt(that.current) - 1);
        if (slideNo == 0) {
            return;
        }

        if (slideNo == 1) {
            $("#previous").addClass('disabled');
            $("#first").addClass('disabled');
        }
        $("#next").removeClass('disabled');
        $("#last").removeClass('disabled');
        that.setCurrent(slideNo, 0);
    });

    $("#first").click(function () {
        slideNo = (parseInt(that.current) - 1);
        if (slideNo == 0) {
            return;
        }
        that.updateToLatest = false;
        that.setCurrent(1, 0);

        $("#previous").addClass('disabled');
        $("#first").addClass('disabled');
        $("#next").removeClass('disabled');
        $("#last").removeClass('disabled');
    });

    $("#next").click(function () {
        if (parseInt(that.latest) == (parseInt(that.current) + 1)) {
            that.updateToLatest = true;
            $("#last").removeClass('new-slide-accent');
        }

        slideNo = (parseInt(that.current) + 1);
        if (slideNo > that.latest) {
            return;
        }

        if (slideNo == that.latest) {
            $("#next").addClass('disabled');
            $("#last").addClass('disabled');
        }

        $("#previous").removeClass('disabled');
        $("#first").removeClass('disabled');
        that.setCurrent(slideNo, 0);
    });

    $("#last").click(function () {
        $("#last").removeClass('new-slide-accent');
        slideNo = (parseInt(that.current) + 1);
        if (slideNo > that.latest) {
            return;
        }
        that.updateToLatest = true;
        that.setCurrent(that.latest, 0);
        $("#previous").removeClass('disabled');
        $("#first").removeClass('disabled');
        $("#next").addClass('disabled');
        $("#last").addClass('disabled');

    });

    $("#downloadlink").click(function () {

        var iOS = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
        if (iOS == true) {
            alert('long click on image then click save');
            return;
        }

        var file = $('#image-slide').attr('src');
        file = parseString(file, '?');
        file = "/viewer/download/" + file;

        var win = window.open(file, '_self');
        win.focus();
    });

    $(".settings-btn").click(function () {
        var btnActive = $(".fixed-action-btn").hasClass('active');
        $(".reco-logo").toggleClass('visible-logo', !btnActive);
        $(".reco-logo").toggleClass('hidden-logo', btnActive);
    });

    $(".image").on("swiperight", function () {
        var hasSlides = $(".fixed-action-btn").is(':visible');
        if (hasSlides) {
            $("#previous").trigger("click");
        }
    });

    $(".image").on("swipeleft", function () {
        var hasSlides = $(".fixed-action-btn").is(':visible');
        if (hasSlides) {
            $("#next").trigger("click");
        }
    });
};
