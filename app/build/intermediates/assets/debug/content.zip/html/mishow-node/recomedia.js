const LISTENING_PORT = 11111;
const CONTROLLER_IP = "127.0.0.1";
const CONTROLLER_LISTENING_PORT = 22222;
const SOCKET_IO_LISTENING_PORT = 3000;
const FILE_UPLOAD_DOWNLOAD_HTTP_SERVER_LISTENING_PORT = 4000;
const SOCKET_IO_PING_INTERVAL = 25000;
const SOCKET_IO_PING_TIMEOUT = 60000;

var http = require('http');
//var https = require('https');
var url = require('url');
var fs = require('fs');
var path = require('path');
var socketio = require('socket.io')(SOCKET_IO_LISTENING_PORT, {
    'pingInterval': SOCKET_IO_PING_INTERVAL,
    'pingTimeout': SOCKET_IO_PING_TIMEOUT
});
var net = require('net');
var express = require('express');
var diskspace = require("diskspace");
var formidable = require('formidable');

console.log("RecoMedia Mobile Controller - version: 1.0.1.4-GX");
console.log("");
console.log("");


function sendMessageToController(msg) {
    var socket = new net.Socket();
    socket.on('data', function (data) {
        console.log('\n[Controller]: Msg from controller: ' + data);
    });
    socket.on('close', function () {
        //console.log('\n[Controller]: Socket closed');
    });
    socket.on('error', function (data) {
        console.log('\n[Controller]: Error sending msg to controller:', data);
    });
    socket.connect(CONTROLLER_LISTENING_PORT, CONTROLLER_IP, function () {
        socket.write(msg, function () {
            console.log('\n[Controller]: Sent msg to controller: ' + msg);
            socket.end();
        });
    });
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Mobile Controller
///////////////////////////////////////////////////////////////////////////////////////////////////

var mishow_node_dir = "/usr/admin_control/mishow-node";
var mishow_node_images_dir = mishow_node_dir + "/images/";
var pad = "000";
var image_index = 0;

var socket_recoserver = null;
var clients = [];
var current_stream_socket = null;

var w = 0,
    h = 0;

const RECEIVER_STATE__NONE = "none";
const RECEIVER_STATE__IMAGE = "image";
const RECEIVER_STATE__VIDEO = "video";
var receiver_state = RECEIVER_STATE__NONE;

socketio.on('connection', function (socket) {
    socket.on('screen-ready', function (data) {
        w = data.width;
        h = data.height;

        console.log("\n[Mob Controller] RecoMedia receiver connected - resolution: " + data.width + " x " + data.height);

        socket_recoserver = socket;
    });

    socket.on('screen-rsize', function (data) {
        w = data.width;
        h = data.height;

        console.log("\n[Mob Controller] RecoMedia receiver resized screen - resolution: " + data.width + " x " + data.height);

        socket_recoserver = socket;

        var res = {
            width: w,
            height: h
        };
        socket.broadcast.emit('resolution', res);
    });

    socket.on('register', function (data) {
        if (socket_recoserver) {
            console.log("\n[Mob Controller] register: A mobile app connected - id: Mob&" + data);

            var i = null;

            clients.forEach(function (client, index) {
                if (data == client.id) {
                    i = index;
                }
            });

            socket.emit('registered', '');

            var res = {
                width: w,
                height: h
            };
            socket.emit('resolution', res);

            if (i == null) {
                var client = {
                    sc: socket,
                    id: data
                };
                clients.push(client);

                // GX 20160616 Disabled on request.
                //sendMessageToController('ESDP Apps&Mobile Mob&' + data + ' ' + LISTENING_PORT + ' 2 0');

                console.log("[Mob Controller] register: # mobile clients: " + clients.length);
            } else {
                console.log("[Mob Controller] register: Mob&" + data + " already registered");

                if (clients[i].sc != socket) {
                    clients[i].sc = socket;
                    console.log("[Mob Controller] register: Mob&" + data + " changed its socket");
                }
            }
        } else {
            console.log("\n[Mob Controller] Error, failed to register mobile app! RecoMedia receiver not connected.");

            socket.emit('errors', 'Unable to connect to server. Code-100');
            socket.disconnect();
        }
    });

    socket.on('image', function (data) {
        // GX: use absolute directory
        var image_name = "image_" + (pad + image_index).slice(-pad.length) + ".jpg";

        var wstream = fs.createWriteStream(mishow_node_images_dir + image_name);
        wstream.write(data.data);
        wstream.end();

        image_index = (image_index + 1) % 10;

        var i = null;

        clients.forEach(function (client, index) {
            if (socket == client.sc) {
                i = index;
            }
        });

        if (i == null) {
            console.log("\n[Mob Controller] image: Unable to match any client with this socket");
        } else {
            console.log("\n[Mob Controller] image: src: Mob&" + clients[i].id + ", resolution: " + data.width + " x " + data.height);

            if (socket_recoserver) {
                socket_recoserver.emit('image', data.data.toString('base64'));
            } else {
                console.log('[Mob Controller] image: RecoMedia receiver not available');
            }

            receiver_state = RECEIVER_STATE__IMAGE;

            sendMessageToController('MESPR Apps&Mobile Mob&' + clients[i].id + ' ' + LISTENING_PORT + ' 1 0');

            if (current_stream_socket != i) {
                if (current_stream_socket != null) {
                    console.log("[Mob Controller] image: Kickout Mob&" + clients[current_stream_socket].id);

                    clients[current_stream_socket].sc.emit('kickout', '');
                    sendMessageToController('MESPSR Apps&Mobile Mob&' + clients[current_stream_socket].id + ' ' + LISTENING_PORT + ' 2 0');
                }

                current_stream_socket = i;
            }
        }
    });

    socket.on('video', function (data) {
        var i = null;

        clients.forEach(function (client, index) {
            if (socket == client.sc) {
                i = index;
            }
        });

        if (i == null) {
            console.log("\n[Mob Controller] video: Unable to match any client with this socket");
        } else {
            console.log("\n[Mob Controller] video: src        : Mob&" + clients[i].id);
            console.log("[Mob Controller] video: ip         : " + data.server_addr);
            console.log("[Mob Controller] video: port       : " + data.server_port);
            console.log("[Mob Controller] video: file       : " + data.video_name);
            console.log("[Mob Controller] video: orientation: " + data.video_rota);

            var response = {
                path: "http://" + data.server_addr + ":" + data.server_port + data.video_name,
                rota: data.video_rota
            }

            console.log("[Mob Controller] video: uri        : " + response.path);

            if (socket_recoserver) {
                socket_recoserver.emit('video', response);
            } else {
                console.log('RecoMedia receiver not available');
            }

            receiver_state = RECEIVER_STATE__VIDEO;

            sendMessageToController('MESPR Apps&Mobile Mob&' + clients[i].id + ' ' + LISTENING_PORT + ' 1 0');

            if (current_stream_socket != i) {
                if (current_stream_socket != null) {
                    console.log("[Mob Controller] video: Kickout Mob&" + clients[current_stream_socket].id);

                    clients[current_stream_socket].sc.emit('kickout', '');
                    sendMessageToController('MESPSR Apps&Mobile Mob&' + clients[current_stream_socket].id + ' ' + LISTENING_PORT + ' 2 0');
                }

                current_stream_socket = i;
            }

            //var http = require('http');
            var options = {
                host: CONTROLLER_IP,
                port: 80,
                path: '/admin/audio/on'
            };

            var req = http.get(options, function (res) {
                console.log('STATUS: ' + res.statusCode);
                console.log('HEADERS: ' + JSON.stringify(res.headers));

                // Buffer the body entirely for processing as a whole.
                var bodyChunks = [];
                res.on('data', function (chunk) {
                    // You can process streamed parts here...
                    bodyChunks.push(chunk);
                }).on('end', function () {
                    var body = Buffer.concat(bodyChunks);
                    console.log('BODY: ' + body);
                    // ...and/or process the entire body here.
                })
            });

            req.on('error', function (e) {
                console.log('ERROR: ' + e.message);
            });
        }
    });

    // GX
    socket.on('video2', function (data) {
        var i = null;

        clients.forEach(function (client, index) {
            if (socket == client.sc) {
                i = index;
            }
        });

        if (i == null) {
            console.log("\n[Mob Controller] video2: Unable to match any client with this socket");
        } else {
            // GX: parse first
            var obj = JSON.parse(data);

            console.log("\n[Mob Controller] video2: src        : Mob&" + clients[i].id);
            console.log("[Mob Controller] video2: ip         : " + obj.server_addr);
            console.log("[Mob Controller] video2: port       : " + obj.server_port);
            console.log("[Mob Controller] video2: file       : " + obj.video_name);
            console.log("[Mob Controller] video2: orientation: " + obj.video_rota);

            var response = null;
            if (obj.server_port == "") {
                response = {
                    path: "http://" + obj.server_addr + "/" + obj.video_name,
                    rota: obj.video_rota
                }
            } else {
                response = {
                    path: "http://" + obj.server_addr + ":" + obj.server_port + "/" + obj.video_name,
                    rota: obj.video_rota
                }
            }

            console.log("[Mob Controller] video2: uri        : " + response.path);

            if (socket_recoserver) {
                socket_recoserver.emit('video', response);
            } else {
                console.log('[Mob Controller] video2: RecoMedia receiver not available');
            }

            receiver_state = RECEIVER_STATE__VIDEO;

            sendMessageToController('MESPR Apps&Mobile Mob&' + clients[i].id + ' ' + LISTENING_PORT + ' 1 0');

            if (current_stream_socket != i) {
                if (current_stream_socket != null) {
                    console.log("[Mob Controller] video2: Kickout Mob&" + clients[current_stream_socket].id);

                    clients[current_stream_socket].sc.emit('kickout', '');
                    sendMessageToController('MESPSR Apps&Mobile Mob&' + clients[current_stream_socket].id + ' ' + LISTENING_PORT + ' 2 0');
                }

                current_stream_socket = i;
            }
        }
    });

    socket.on('video_forward', function (data) {
        console.log('\n[Mob Controller] video_forward: ' + data);

        if (receiver_state == RECEIVER_STATE__VIDEO) {
            var i = null;

            clients.forEach(function (client, index) {
                if (socket == client.sc) {
                    i = index;
                }
            });

            if ((i != null) && (i == current_stream_socket) && socket_recoserver) {
                socket_recoserver.emit('video_forward', data);
            }
        } else {
            console.log("[Mob Controller] video_forward: Unexpected event, current receiver state:", receiver_state);
        }
    });

    // GX: pause video playback
    socket.on('video_pause', function () {
        console.log('\n[Mob Controller] video_pause');

        if (receiver_state == RECEIVER_STATE__VIDEO) {
            var i = null;

            clients.forEach(function (client, index) {
                if (socket == client.sc) {
                    i = index;
                }
            });

            if ((i != null) && (i == current_stream_socket) && socket_recoserver) {
                socket_recoserver.emit('video_pause', "");
            }
        } else {
            console.log("[Mob Controller] video_pause: Unexpected event, current receiver state:", receiver_state);
        }
    });

    // GX: resume video playback
    socket.on('video_resume', function () {
        console.log('\n[Mob Controller] video_resume');

        if (receiver_state == RECEIVER_STATE__VIDEO) {
            var i = null;

            clients.forEach(function (client, index) {
                if (socket == client.sc) {
                    i = index;
                }
            });

            if ((i != null) && (i == current_stream_socket) && socket_recoserver) {
                socket_recoserver.emit('video_resume', "");
            }
        } else {
            console.log("[Mob Controller] video_resume: Unexpected event, current receiver state:", receiver_state);
        }
    });

    socket.on('video_timeupdate', function (data) {
        console.log("\n[Mob Controller] video_timeupdate", parseInt(data * 1000));

        if (receiver_state == RECEIVER_STATE__VIDEO) {
            if (clients[current_stream_socket]) {
                clients[current_stream_socket].sc.emit("video_timeupdate", parseInt(data * 1000));
            }
        } else {
            console.log("[Mob Controller] video_timeupdate: Unexpected event, current receiver state:", receiver_state);
        }
    });

    // GX: get video duration from the remote player
    socket.on('video_duration', function (data) {
        console.log("\n[Mob Controller] video_duration", parseInt(data * 1000));

        if (receiver_state == RECEIVER_STATE__VIDEO) {
            if (clients[current_stream_socket]) {
                clients[current_stream_socket].sc.emit("video_duration", parseInt(data * 1000));
            }
        } else {
            console.log("[Mob Controller] video_duration: Unexpected event, current receiver state:", receiver_state);
        }
    });

    socket.on('video_ended', function (data) {
        console.log("\n[Mob Controller] video_ended");

        if (receiver_state == RECEIVER_STATE__VIDEO) {
            // GX: return to the welcome page
            if (socket_recoserver) {
                socket_recoserver.emit('dismiss', '')
            }

            if (clients[current_stream_socket]) {
                clients[current_stream_socket].sc.emit("video_ended", "");
                current_stream_socket = null;
            }
        } else {
            console.log("[Mob Controller] video_ended: Unexpected event, current receiver state:", receiver_state);
        }
    });

    socket.on('dismiss', function (data) {
        console.log("\n[Mob Controller] dismiss");

        var i = null;

        clients.forEach(function (client, index) {
            if (socket == client.sc) {
                i = index;
            }
        });

        if (i == null) {
            console.log("[Mob Controller] dismiss: Unable to match any client with this socket");
        } else {
            if (i == current_stream_socket) {
                if (socket_recoserver) {
                    socket_recoserver.emit('dismiss', '');
                }

                receiver_state = RECEIVER_STATE__NONE;

                sendMessageToController('MESPSR Apps&Mobile Mob&' + clients[current_stream_socket].id + ' ' + LISTENING_PORT + ' 2 0');

                current_stream_socket = null;
            }
        }
    });

    socket.on('disconnect', function () {
        if (socket == socket_recoserver) {
            console.log("\n[Mob Controller] disconnect: RecoMedia receiver disconnected");

            if (current_stream_socket != null) {
                console.log("[Mob Controller] disconnect: Media file streaming is ongoing, reset current mobile streamer");

                clients[current_stream_socket].sc.emit('reset', '');
                receiver_state = RECEIVER_STATE__NONE;
                current_stream_socket = null;
            }

            socket_recoserver = null;
        } else {
            var i = null;

            clients.forEach(function (client, index) {
                if (socket == client.sc) {
                    i = index;
                }
            });

            if (i == null) {
                console.log("\n[Mob Controller] disconnect: Unable to match any client with this socket");
            } else {
                console.log("\n[Mob Controller] disconnect: Mob&" + clients[i].id + " disconnected");

                // GX: The disconnected client was the one streaming
                if (i == current_stream_socket) {
                    console.log("[Mob Controller] disconnect: Mob&" + clients[i].id + " was streaming, dismiss media streaming");

                    if (socket_recoserver) {
                        socket_recoserver.emit('dismiss', '');
                    }

                    receiver_state = RECEIVER_STATE__NONE;

                    //sendMessageToController('MESPSR Apps&Mobile Mob&' + clients[current_stream_socket].id + ' ' + LISTENING_PORT + ' 2 0');

                    current_stream_socket = null;
                }

                sendMessageToController('ESQ Apps&Mobile Mob&' + clients[i].id + ' ' + LISTENING_PORT + ' 1 0');

                clients.splice(i, 1);
            }
        }
    });
});


///////////////////////////////////////////////////////////////////////////////////////////////////
// File Upload/Download
///////////////////////////////////////////////////////////////////////////////////////////////////

var app = express();

var fileList = [];
var foldSize = 0;

//var upload_root = __dirname;
var upload_root = mishow_node_dir;
var upload_fold = "upload";
var upload_path = upload_root + "/" + upload_fold;

function populateFileList(currentDirPath) {
    fileList = [];
    foldSize = 0;

    fs.readdir(currentDirPath, function (err, files) {
        var fileIndx = 0;

        files.forEach(function (file) {
            var hidden = (file.substr(0, 1) == ".") ? true : false;

            var stat = fs.statSync(path.resolve(currentDirPath, file)); // yes sometimes async does not make sense!
            //var info = {};

            if (stat.isFile() && !hidden) {
                //var date = stat.mtime.getTime();
                //date: dateFormat(stat.mtime, "dddd, mmmm dS, yyyy, h:MM:ss TT")
                foldSize += stat.size;
                fileIndx++;

                var info = {
                    indx: fileIndx,
                    name: file,
                    size: stat.size,
                    date: stat.mtime,
                    /*dateFormat(stat.mtime, "mmmm dd, yyyy hh:MM"),*/
                    user: 'Administrator'
                }

                fileList.push(info);
            } else {
                console.log("[File UL/DL] populateFileList(): read dir: " + file + " is not a file");
            }
        });

        diskspace.check(upload_path, function (err, total, free, status) {
            console.log("[File UL/DL] populateFileList(): total: " + total + " B, free: " + free + " B, status: " + status);
        });

        console.log("[File UL/DL] populateFileList(): file list:\n", fileList);
    });
}
populateFileList(upload_path);

//const httpsServerOptions = {
//    cert: fs.readFileSync('/opt/mipresent/mi-display-controller/ssl/cacert.pem'),
//    key: fs.readFileSync('/opt/mipresent/mi-display-controller/ssl/privkey.pem')
//};
//var httpsServer = https.createServer(httpsServerOptions, app);
//httpsServer.listen(4000);

var httpServer = http.createServer(app);
httpServer.listen(FILE_UPLOAD_DOWNLOAD_HTTP_SERVER_LISTENING_PORT);
console.log("[File UL/DL] HTTP server listening on ", httpServer.address());

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
app.post('/upload', function (req, res) {
    console.log('\n[File UL/DL] Upload...');

    var form = new formidable.IncomingForm();
    form.multiples = false;
    form.uploadDir = upload_path;

    form.on('file', function (field, file) {
        var duplicate = true;
        var file_number = 0;

        var file_tosave = file.name;

        while (duplicate) {
            console.log("[File UL/DL] Trying to save as: " + file_tosave);

            try {
                var stats = fs.statSync(path.join(form.uploadDir, file_tosave));

                var info = path.parse(file.name);

                file_tosave = info.name + "-(" + file_number + ")" + info.ext;
                file_number++;

                console.log("[File UL/DL] File exists, append index: " + file_tosave);
            } catch (err) {
                duplicate = false;
                fs.rename(file.path, path.join(form.uploadDir, file_tosave));

                console.log("[File UL/DL] Saving as new file: " + file_tosave);
            }
        }
    });

    form.on('error', function (err) {
        console.log('[File UL/DL] An error has occured: \n' + err);
    });

    form.on('end', function () {
        populateFileList(upload_path);
        res.end('success');
    });

    form.parse(req);
});
app.post('/filelist', function (req, res) {
    console.log('\n[File UL/DL] Request for filelist...');

    var value = {
        size: foldSize,
        file: fileList
    }
    res.writeHead(200, {
        'Content-type': 'application/json'
    });
    res.end(JSON.stringify(value));
});
app.post('/delete', function (req, res) {
    req.on('data', function (filename) {
        console.log("\n[File UL/DL] Request to delete: " + filename);

        var file = upload_path + '/' + filename;

        fs.stat(file, function (err, stats) {
            if (err) {
                console.log('[File UL/DL] File: ' + file + ' not found, so not deleting');
                return console.error(err);
            }

            console.log('[File UL/DL] Deleting file: ' + file);

            fs.unlink(file, function (err) {
                if (err) {
                    return console.log(err);
                } else {
                    populateFileList(upload_path);
                    console.log('[File UL/DL] File deleted successfully');

                    res.writeHead(200, {
                        'Connection': 'close'
                    });
                    res.end("deleted");
                }
            });
        });
    });
});
app.get('/download', function (req, res) {
    var data = url.parse(req.url, true);

    console.log('\n[File UL/DL] Request for file: ' + path.join(upload_path, data.query.file));

    fs.readFile(path.join(upload_path, data.query.file), function (err, content) {
        if (err) {
            console.log(err);

            res.writeHead(400, {
                'Content-type': 'text/html',
            })
            res.end("<!DOCTYPE html>" +
                "<html>" +
                "<body>" +
                "<h1>Requested file not found on the server.</h1>" +
                "</body>" +
                "</html>");
        } else {
            res.setHeader('Content-Disposition', 'attachment; filename=' + encodeURIComponent(data.query.file));
            res.end(content);
        }
    });
});


///////////////////////////////////////////////////////////////////////////////////////////////////
// Server for listening for commands from the controller
///////////////////////////////////////////////////////////////////////////////////////////////////

var serverSocket = net.createServer(function (socket) {
    socket.on('data', function (data) {
        console.log("\n[Controller] Msg from controller: " + data);

        if (data == "cancel") {
            if (current_stream_socket != null) {
                console.log("[Controller] Controller ask to kickout Mob&" + clients[current_stream_socket].id);

                clients[current_stream_socket].sc.emit('kickout', '');

                if (socket_recoserver) {
                    socket_recoserver.emit('dismiss', '');
                }

                current_stream_socket = null;
            }
        }
    });
});
serverSocket.listen(LISTENING_PORT, CONTROLLER_IP);
console.log("[Controller] Listening for controller messages on port " + LISTENING_PORT + "...");
