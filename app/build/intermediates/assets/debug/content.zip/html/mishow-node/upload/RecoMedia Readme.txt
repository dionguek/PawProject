RecoMedia is a cross-platform screen sharing system. It comes with a media box which you need to connect to your projector or TV, and serves WiFi connectivity to receive contents you want to share from your laptop.

You can download the RecoMedia application directly from the media box. Follow the simple instructions showed on the TV/projector screen.

Features of RecoMedia:

� Wirelessly share multimedia content from laptops and mobile phones
� Support Windows, Apple Mac OSX computers, Android and iOS smartphones
� Configurable video output resolution
� Auto recommendation of resolution to match with display device
� Configurable wireless channel (2.4 or 5 GHz)
� Allow user to initiate the sharing directly from the PC, or
� Log in to moderator mode where user can select any presenter�s computer to share its desktop screen
� Allow user to stream media or video files from PC or smartphones
� Enable user to optionally share only the extended screen
� Allow participants to access, navigate and save the presentation content live as it is being presented using just browser with no app installation
� Support uploading and downloading of contents for offline consumption
� Support up to 32 registered client devices
� Provide option to set up a password-protected WiFi connectivity (WPA2)
